Carpeta "plantillas\pcm"
------------------------------------------------------------------------------------------

Carpeta donde se encuentra el template para completar para la carga de gu�as autom�ticas.

NO BORRAR el archivo "PLANTILLA_CARGA_MASIVA.xlsx".
