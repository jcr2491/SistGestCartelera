Carpeta "plantillas"
------------------------------------------------------------------------------------------

Carpeta donde se guardan las plantillas cargadas a trav�s de la opci�n "Configuraci�n - Configuraci�n Cartel"