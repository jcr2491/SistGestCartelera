Carpeta "plantillas\gma"
------------------------------------------------------------------------------------------

Carpeta donde se guardan las gu�as autom�tica cargadas.
Estos archivos son cargados por el usuario a trav�s de la opci�n "Carteler�a - Creaci�n Autom�tica".
Todos los archivos EXCEL (xls o xlsx) pueden ser eliminados.