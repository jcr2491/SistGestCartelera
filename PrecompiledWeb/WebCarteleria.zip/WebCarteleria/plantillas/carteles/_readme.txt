Carpeta "plantillas\carteles"
------------------------------------------------------------------------------------------

Carpeta donde se guardan los carteles generados por los usuarios.
Todos los archivos EXCEL (xls o xlsx) pueden ser eliminados.